/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.kuisulang2;

/**
 *
 * @author User
 */
public class KuisUlang2 {

    public static void main(String[] args) {
        KaryawanTetap karyawanTetap = new KaryawanTetap ("Dwi", "19016798", 3000000);
        KaryawanKontrak karyawanKontrak = new KaryawanKontrak ("Aini", "190253", 100000, 10);
        IDGaji[] daftarGaji = new IDGaji[2];
        
        
        for (int i = 0; i <= 2 ; i++){
            System.out.println ("Karyawan ke-" + (i+1) );
            karyawanTetap.tampilkanSlipGaji();
        }
        
        for (int j = 0; j <= 2 ; j++){
            System.out.println ("Karyawan ke-" + (j+1) );
            karyawanKontrak.tampilkanSlipGaji();
        }
    
    }
}
