/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.aplikasimanajemensuratmasuk.model;

/**
 *
 * @author User
 */
public class User {
    private int id_user;
    private String username;
    private String password;
    private String nama_lengkap;
    private String no_hp;
    private String nim;
    private String role;
    

    public User() {
    }

    public User(int id_user, String username, String password, String nama_lengkap, String no_hp, String nim, String role) {
        this.id_user = id_user;
        this.username = username;
        this.password = password;
        this.nama_lengkap = nama_lengkap;
        this.no_hp = no_hp;
        this.nim = nim;
        this.role = role;
    }

    public User(String username, String password, String nama_lengkap, String no_hp, String nim, String role) {
        this.username = username;
        this.password = password;
        this.nama_lengkap = nama_lengkap;
        this.no_hp = no_hp;
        this.nim = nim;
        this.role = role;
    }

    public int getId_user() {
        return id_user;
    }

    public void setId_user(int id_user) {
        this.id_user = id_user;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getNama_lengkap() {
        return nama_lengkap;
    }

    public void setNama_lengkap(String nama_lengkap) {
        this.nama_lengkap = nama_lengkap;
    }

    public String getNo_hp() {
        return no_hp;
    }

    public void setNo_hp(String no_hp) {
        this.no_hp = no_hp;
    }

    public String getNim() {
        return nim;
    }

    public void setNim(String nim) {
        this.nim = nim;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }
    
    
}

