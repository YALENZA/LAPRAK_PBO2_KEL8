package com.mycompany.aplikasimanajemensuratmasuk.dao;

import com.mycompany.aplikasimanajemensuratmasuk.model.SuratMasuk;
import com.mycompany.aplikasimanajemensuratmasuk.config.Koneksi;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class SuratMasukDAO {

    // INSERT DATA
    public static void insert(SuratMasuk s) throws SQLException {
        String sql = "INSERT INTO surat_masuk(no_surat, tanggal_masuk, pengirim, penerima, perihal, lampiran, foto, status) VALUES (?,?,?,?,?,?,?,?)";

        try (Connection c = Koneksi.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {

            ps.setString(1, s.getNoSurat());
            ps.setString(2, s.getTanggalMasuk());
            ps.setString(3, s.getPengirim());
            ps.setString(4, s.getPenerima());
            ps.setString(5, s.getPerihal());
            ps.setString(6, s.getLampiran());
            ps.setString(7, s.getFoto());
            ps.setString(8, s.getStatus());

            ps.executeUpdate();
        }
    }

    // UPDATE BY ID
    public static void updateById(SuratMasuk s) throws SQLException {
        String sql = """
            UPDATE surat_masuk SET 
                no_surat = ?, tanggal_masuk = ?, pengirim = ?, penerima = ?, 
                perihal = ?, lampiran = ?, foto = ?, status = ?
            WHERE id = ?
        """;

        try (Connection c = Koneksi.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {

            ps.setString(1, s.getNoSurat());
            ps.setString(2, s.getTanggalMasuk());
            ps.setString(3, s.getPengirim());
            ps.setString(4, s.getPenerima());
            ps.setString(5, s.getPerihal());
            ps.setString(6, s.getLampiran());
            ps.setString(7, s.getFoto());
            ps.setString(8, s.getStatus());
            ps.setInt(9, s.getId());

            ps.executeUpdate();
        }
    }

    // FIND BY ID
    public static SuratMasuk findById(int id) throws SQLException {
        String sql = "SELECT * FROM surat_masuk WHERE id = ?";

        try (Connection c = Koneksi.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {

            ps.setInt(1, id);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    SuratMasuk s = new SuratMasuk();
                    s.setId(rs.getInt("id"));
                    s.setNoSurat(rs.getString("no_surat"));
                    s.setTanggalMasuk(rs.getString("tanggal_masuk"));
                    s.setPengirim(rs.getString("pengirim"));
                    s.setPenerima(rs.getString("penerima"));
                    s.setPerihal(rs.getString("perihal"));
                    s.setLampiran(rs.getString("lampiran"));
                    s.setFoto(rs.getString("foto"));
                    s.setStatus(rs.getString("status"));
                    return s;
                }
            }
        }
        return null;
    }
    
    // FUNGSI MENGHITUNG TOTAL SURAT MASUK (Untuk Dashboard)
    public static int getCount() throws SQLException {
        int total = 0;
        String sql = "SELECT COUNT(*) AS total FROM surat_masuk";

        try (Connection c = Koneksi.getConnection();
             Statement s = c.createStatement();
             ResultSet rs = s.executeQuery(sql)) {

            if (rs.next()) {
                total = rs.getInt("total");
            }
        }
        return total;
    }

    // DELETE BY ID
    public static void deleteById(int idSurat) throws SQLException {
        // 1. Hapus dulu data anaknya (Disposisi)
        String sqlDisposisi = "DELETE FROM surat_disposisi WHERE id_surat_masuk = ?";
        try (java.sql.Connection c = Koneksi.getConnection();
             java.sql.PreparedStatement ps = c.prepareStatement(sqlDisposisi)) {
            ps.setInt(1, idSurat);
            ps.executeUpdate();
        }

        // 2. Baru hapus data induknya (Surat Masuk)
        String sqlSurat = "DELETE FROM surat_masuk WHERE id = ?";
        try (java.sql.Connection c = Koneksi.getConnection();
             java.sql.PreparedStatement ps = c.prepareStatement(sqlSurat)) {
            ps.setInt(1, idSurat);
            ps.executeUpdate();
        }
    }

    // GET ALL
    public static List<SuratMasuk> getAll() throws SQLException {
        List<SuratMasuk> list = new ArrayList<>();
        String sql = "SELECT * FROM surat_masuk ORDER BY id DESC";

        try (Connection c = Koneksi.getConnection();
             Statement st = c.createStatement();
             ResultSet rs = st.executeQuery(sql)) {

            while (rs.next()) {
                SuratMasuk s = new SuratMasuk();
                s.setId(rs.getInt("id"));
                s.setNoSurat(rs.getString("no_surat"));
                s.setTanggalMasuk(rs.getString("tanggal_masuk"));
                s.setPengirim(rs.getString("pengirim"));
                s.setPenerima(rs.getString("penerima"));
                s.setPerihal(rs.getString("perihal"));
                s.setLampiran(rs.getString("lampiran"));
                s.setFoto(rs.getString("foto"));
                s.setStatus(rs.getString("status"));

                list.add(s);
            }
        }
        return list;
    }
    
    public static int insertAndGetId(SuratMasuk s) throws SQLException {
    String sql = "INSERT INTO surat_masuk(no_surat, tanggal_masuk, pengirim, penerima, perihal, lampiran, foto, status) VALUES (?,?,?,?,?,?,?,?)";

    try (Connection c = Koneksi.getConnection();
         PreparedStatement ps = c.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

        ps.setString(1, s.getNoSurat());
        ps.setString(2, s.getTanggalMasuk());
        ps.setString(3, s.getPengirim());
        ps.setString(4, s.getPenerima());
        ps.setString(5, s.getPerihal());
        ps.setString(6, s.getLampiran());
        ps.setString(7, s.getFoto());
        ps.setString(8, s.getStatus());

        ps.executeUpdate();

        try (ResultSet rs = ps.getGeneratedKeys()) {
            if (rs.next()) {
                int id = rs.getInt(1);
                s.setId(id); // update objek
                return id;
            }
        }
    }
    throw new SQLException("Gagal mendapatkan ID hasil insert");
}

}
