package com.mycompany.aplikasimanajemensuratmasuk.attaya;

import java.awt.*;
import javax.swing.*;

public class RoundedShadowPanel2 extends JPanel {

    private int radius = 70;

    public RoundedShadowPanel2() {
        setOpaque(false);
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);

        Graphics2D g2 = (Graphics2D) g.create();
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        int shadowOffset = 12;

        // ====== MULTI LAYER SHADOW (lebih halus) ======
        for (int i = 0; i < 10; i++) {
            g2.setColor(new Color(0, 0, 0, 15 - i));    // makin ke luar makin transparan
            g2.fillRoundRect(
                    shadowOffset - i,
                    shadowOffset - i,
                    getWidth() - (shadowOffset - i) * 2,
                    getHeight() - (shadowOffset - i) * 2,
                    radius,
                    radius
            );
        }

        // ====== PANEL PUTIH ======
        g2.setColor(Color.WHITE);
        g2.fillRoundRect(
                0,
                0,
                getWidth() - shadowOffset,
                getHeight() - shadowOffset,
                radius,
                radius
        );

        g2.dispose();
    }
}
