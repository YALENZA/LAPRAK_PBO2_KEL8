/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.aplikasimanajemensuratmasuk.model;

/**
 *
 * @author User
 */
public class Disposisi {

    private String id_disposisi;
    private String id_surat_masuk;
    private String disposisi_ke;
    private String instruksi;
    private String tanggal_disposisi;
    private String status;
    private String no_surat;
    private String penerima;
    private String foto;
    private String lampiran;

    public String getFoto() {
        return foto;
    }

    public void setFoto(String foto) {
        this.foto = foto;
    }

    public String getLampiran() {
        return lampiran;
    }

    public void setLampiran(String lampiran) {
        this.lampiran = lampiran;
    }

    public Disposisi() {
    }

    public Disposisi(String id_surat_masuk, String disposisi_ke, String instruksi, String tanggal_disposisi, String status) {
        this.id_surat_masuk = id_surat_masuk;
        this.disposisi_ke = disposisi_ke;
        this.instruksi = instruksi;
        this.tanggal_disposisi = tanggal_disposisi;
        this.status = status;
    }

    public Disposisi(String id_disposisi, String id_surat_masuk, String disposisi_ke, String instruksi, String tanggal_disposisi, String status) {
        this.id_disposisi = id_disposisi;
        this.id_surat_masuk = id_surat_masuk;
        this.disposisi_ke = disposisi_ke;
        this.instruksi = instruksi;
        this.tanggal_disposisi = tanggal_disposisi;
        this.status = status;
    }

    public String getId_disposisi() {
        return id_disposisi;
    }

    public void setId_disposisi(String id_disposisi) {
        this.id_disposisi = id_disposisi;
    }

    public String getId_surat_masuk() {
        return id_surat_masuk;
    }

    public void setId_surat_masuk(String id_surat_masuk) {
        this.id_surat_masuk = id_surat_masuk;
    }

    public String getDisposisi_ke() {
        return disposisi_ke;
    }

    public void setDisposisi_ke(String disposisi_ke) {
        this.disposisi_ke = disposisi_ke;
    }

    public String getInstruksi() {
        return instruksi;
    }

    public void setInstruksi(String instruksi) {
        this.instruksi = instruksi;
    }

    public String getTanggal_disposisi() {
        return tanggal_disposisi;
    }

    public void setTanggal_disposisi(String tanggal_disposisi) {
        this.tanggal_disposisi = tanggal_disposisi;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getNo_surat() {
        return no_surat;
    }

    public void setNo_surat(String no_surat) {
        this.no_surat = no_surat;
    }

    public String getPenerima() {
        return penerima;
    }

    public void setPenerima(String penerima) {
        this.penerima = penerima;
    }

}
