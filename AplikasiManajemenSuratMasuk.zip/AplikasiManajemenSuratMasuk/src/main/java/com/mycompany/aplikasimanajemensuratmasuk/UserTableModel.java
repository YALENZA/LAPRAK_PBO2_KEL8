package com.mycompany.aplikasimanajemensuratmasuk;

import java.sql.*;
import java.util.*;
import javax.swing.table.AbstractTableModel;

public class UserTableModel extends AbstractTableModel {

    private final String[] columns = { "No", "NIM", "Nama", "Tanggal", "Status", "Aksi" };
    private final List<UserRow> data = new ArrayList<>();

    public UserTableModel() {
        loadData();
    }

    private void loadData() {
        try {
            Connection con = DriverManager.getConnection(
                    "jdbc:mysql://localhost/db_surat", "root", "");

            String sql = "SELECT * FROM user";
            PreparedStatement ps = con.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();

            int no = 1;
            while (rs.next()) {
                data.add(new UserRow(
                        no++,
                        rs.getString("nim"),
                        rs.getString("nama_lengkap"),
                        rs.getString("tanggal"),
                        rs.getString("status")
                ));
            }

            rs.close();
            ps.close();
            con.close();

        } catch (Exception e) {
            System.err.println("Error load: " + e.getMessage());
        }
    }

    @Override public int getRowCount() { return data.size(); }
    @Override public int getColumnCount() { return columns.length; }
    @Override public String getColumnName(int c) { return columns[c]; }

    @Override
    public Object getValueAt(int row, int col) {
        UserRow d = data.get(row);

        return switch (col) {
            case 0 -> d.no;
            case 1 -> d.nim;
            case 2 -> d.nama;
            case 3 -> d.tanggal;
            case 4 -> d.status;
            case 5 -> "Aksi"; // kolom tombol
            default -> null;
        };
    }

    public static class UserRow {
        int no;
        String nim, nama, tanggal, status;

        public UserRow(int no, String nim, String nama, String tanggal, String status) {
            this.no = no;
            this.nim = nim;
            this.nama = nama;
            this.tanggal = tanggal;
            this.status = status;
        }
    }
}
