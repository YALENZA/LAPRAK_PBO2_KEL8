package com.mycompany.aplikasimanajemensuratmasuk.attaya;

import java.awt.*;
import java.awt.geom.*;
import javax.swing.*;

public class FormUbahSurat extends JPanel {

    private int topRadius = 40; // default radius untuk bagian atas

    public FormUbahSurat() {
        setOpaque(false);
    }

    public FormUbahSurat(int topRadius) {
        this.topRadius = topRadius;
        setOpaque(false);
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);

        Graphics2D g2 = (Graphics2D) g;
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
                            RenderingHints.VALUE_ANTIALIAS_ON);

        int w = getWidth();
        int h = getHeight();
        int r = topRadius;

        Path2D path = new Path2D.Float();

        // kiri atas melengkung
        path.moveTo(0, r);
        path.quadTo(0, 0, r, 0);

        // kanan atas melengkung
        path.lineTo(w - r, 0);
        path.quadTo(w, 0, w, r);

        // bagian bawah normal
        path.lineTo(w, h);
        path.lineTo(0, h);

        path.closePath();

        g2.setColor(getBackground());
        g2.fill(path);
    }
}
