package com.mycompany.aplikasimanajemensuratmasuk.dao;

import com.mycompany.aplikasimanajemensuratmasuk.model.Disposisi;
import com.mycompany.aplikasimanajemensuratmasuk.config.Koneksi;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class DisposisiDAO {

    // INSERT
    public static void insert(Disposisi d) throws SQLException {
        String sql = """
            INSERT INTO surat_diposisi (id_surat_masuk, disposisi_ke, instruksi, tanggal_disposisi, status)
            VALUES (?,?,?,?,?)
        """;

        try (Connection c = Koneksi.getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, d.getId_surat_masuk());
            ps.setString(2, d.getDisposisi_ke());
            ps.setString(3, d.getInstruksi());
            ps.setString(4, d.getTanggal_disposisi());
            ps.setString(5, d.getStatus());
            ps.executeUpdate();
        }
    }

    // UPDATE STATUS
    public static void updateStatus(String idDisposisi, String newStatus) throws SQLException {
        String sql = "UPDATE surat_diposisi SET status = ? WHERE id_disposisi = ?";

        try (Connection c = Koneksi.getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, newStatus);
            ps.setString(2, idDisposisi);
            ps.executeUpdate();
        }

        // Ambil id_surat_masuk dari disposisi yang diupdate
        String sqlSelect = "SELECT id_surat_masuk FROM surat_diposisi WHERE id_disposisi = ?";
        try (Connection c = Koneksi.getConnection(); PreparedStatement ps = c.prepareStatement(sqlSelect)) {
            ps.setString(1, idDisposisi);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                String idSuratMasuk = rs.getString("id_surat_masuk");
                // Jika status di disposisi selesai, update status surat_masuk
                if ("Selesai".equalsIgnoreCase(newStatus)) {
                    String sqlUpdateSurat = "UPDATE surat_masuk SET status = 'Selesai' WHERE id = ?";
                    try (PreparedStatement ps2 = c.prepareStatement(sqlUpdateSurat)) {
                        ps2.setString(1, idSuratMasuk);
                        ps2.executeUpdate();
                    }
                }
            }
        }
    }

    // GET ALL (JOIN AGAR MENGAMBIL no_surat & penerima)
    public static List<Disposisi> getAll() throws SQLException {
        List<Disposisi> list = new ArrayList<>();

        String sql = """
            SELECT 
                d.id_disposisi,
                d.id_surat_masuk,
                sm.no_surat,
                sm.penerima,
                d.disposisi_ke,
                d.instruksi,
                d.tanggal_disposisi,
                d.status,
                sm.foto,
                sm.lampiran     
            FROM surat_diposisi d
            LEFT JOIN surat_masuk sm ON sm.id = d.id_surat_masuk
            ORDER BY d.id_disposisi DESC
        """;

        try (Connection c = Koneksi.getConnection(); Statement st = c.createStatement(); ResultSet rs = st.executeQuery(sql)) {

            while (rs.next()) {
                Disposisi d = new Disposisi();
                d.setId_disposisi(rs.getString("id_disposisi"));
                d.setId_surat_masuk(rs.getString("id_surat_masuk"));
                d.setDisposisi_ke(rs.getString("disposisi_ke"));  // tambahkan ini
                d.setNo_surat(rs.getString("no_surat"));
                d.setPenerima(rs.getString("penerima"));
                d.setInstruksi(rs.getString("instruksi"));
                d.setTanggal_disposisi(rs.getString("tanggal_disposisi"));
                d.setStatus(rs.getString("status"));
                d.setFoto(rs.getString("foto"));       // <-- tambah ini
                d.setLampiran(rs.getString("lampiran")); // <-- tambah ini
                list.add(d);
            }
        }
        return list;
    }

    public static void insertAuto(String idSurat, String penerima, String lampiran, String foto) throws SQLException {
        String sql = """
            INSERT INTO surat_diposisi (id_surat_masuk, disposisi_ke, instruksi, tanggal_disposisi, status, lampiran, foto)
            VALUES (?,?,?,?,?,?,?)
        """;

        try (Connection c = Koneksi.getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, Integer.parseInt(idSurat));
            ps.setString(2, penerima);
            ps.setString(3, "-");
            ps.setString(4, java.time.LocalDate.now().toString());
            ps.setString(5, "proses");
            ps.setString(6, lampiran);                    // lampiran
            ps.setString(7, foto);
            ps.executeUpdate();
        }
    }
}
