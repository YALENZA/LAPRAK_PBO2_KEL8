package com.mycompany.aplikasimanajemensuratmasuk.abang;

import java.awt.*;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.awt.geom.RoundRectangle2D;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.plaf.metal.MetalTextFieldUI;

/**
 * Custom JTextField dengan border rounded dan warna yang bisa dikustomisasi penuh.
 */
public class Custom_JTextFieldRounded extends JTextField {

    private final TextFieldUI textUI;

    public Custom_JTextFieldRounded() {
        textUI = new TextFieldUI(this);
        setUI(textUI);
    }

    // === Setter & Getter untuk warna ===
    public void setRound(int round) {
        textUI.setRound(round);
    }

    public int getRound() {
        return textUI.getRound();
    }

    public void setBorderColor(Color color) {
        textUI.getBorder().setColor(color);
        repaint();
    }

    public void setFocusColor(Color color) {
        textUI.getBorder().setFocusColor(color);
        repaint();
    }

    public void setBackgroundColor(Color color) {
        textUI.setBackgroundColor(color);
        repaint();
    }

    public void setPlaceholderColor(Color color) {
        textUI.setPlaceholderColor(color);
        repaint();
    }

    public void setPlaceholder(String text) {
        textUI.setPlaceholder(text);
        repaint();
    }

    public String getPlaceholder() {
        return textUI.getPlaceholder();
    }

    public Color getBorderColor() {
        return textUI.getBorder().getColor();
    }

    public Color getFocusColor() {
        return textUI.getBorder().getFocusColor();
    }

    public Color getBackgroundColor() {
        return textUI.getBackgroundColor();
    }

    public Color getPlaceholderColor() {
        return textUI.getPlaceholderColor();
    }

    // === Inner class utama ===
    private static class TextFieldUI extends MetalTextFieldUI {

        private final JTextField textfield;
        private final Border border;
        private int round = 15;
        private Color backgroundColor = Color.WHITE;
        private Color placeholderColor = new Color(160, 160, 160);
        private String placeholder = "";

        public TextFieldUI(JTextField textfield) {
            this.textfield = textfield;
            border = new Border(10);
            border.setRound(round);
            textfield.setBorder(border);
            textfield.setOpaque(false);
            textfield.setSelectedTextColor(Color.WHITE);
            textfield.setSelectionColor(new Color(54, 189, 248));

            // Efek focus
            textfield.addFocusListener(new FocusAdapter() {
                @Override
                public void focusGained(FocusEvent fe) {
                    border.setActive(true);
                    textfield.repaint();
                }

                @Override
                public void focusLost(FocusEvent fe) {
                    border.setActive(false);
                    textfield.repaint();
                }
            });
        }

        public void setRound(int round) {
            this.round = round;
            border.setRound(round);
            textfield.repaint();
        }

        public int getRound() {
            return round;
        }

        public Border getBorder() {
            return border;
        }

        public void setBackgroundColor(Color color) {
            this.backgroundColor = color;
        }

        public Color getBackgroundColor() {
            return backgroundColor;
        }

        public void setPlaceholder(String text) {
            this.placeholder = text;
        }

        public String getPlaceholder() {
            return placeholder;
        }

        public void setPlaceholderColor(Color color) {
            this.placeholderColor = color;
        }

        public Color getPlaceholderColor() {
            return placeholderColor;
        }

        @Override
        protected void paintBackground(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

            int w = textfield.getWidth();
            int h = textfield.getHeight();

            // tambahkan padding agar border tidak terpotong
            Shape shape = new RoundRectangle2D.Double(
                    0.5, 0.5,
                    w - 1.0, h - 1.0,
                    round, round
            );

            g2.setColor(backgroundColor);
            g2.fill(shape);

            g2.dispose();
        }

        @Override
        protected void paintSafely(Graphics g) {
            super.paintSafely(g);

            // Gambar placeholder jika teks kosong
            if (textfield.getText().isEmpty() && !textfield.hasFocus() && !placeholder.isEmpty()) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(placeholderColor);
                FontMetrics fm = g2.getFontMetrics();
                int y = (textfield.getHeight() - fm.getHeight()) / 2 + fm.getAscent();
                g2.drawString(placeholder, 10, y);
                g2.dispose();
            }
        }

        // === Inner class Border ===
        private static class Border extends EmptyBorder {

            private Color color = new Color(206, 212, 218);
            private Color focusColor = new Color(20, 93, 146); // warna utama (#145d92)
            private int round;
            private boolean active = false;

            public Border(int padding) {
                super(padding, padding, padding, padding);
            }

            public void setColor(Color color) {
                this.color = color;
            }

            public Color getColor() {
                return color;
            }

            public void setFocusColor(Color color) {
                this.focusColor = color;
            }

            public Color getFocusColor() {
                return focusColor;
            }

            public void setRound(int round) {
                this.round = round;
            }

            public int getRound() {
                return round;
            }

            public void setActive(boolean active) {
                this.active = active;
            }

            @Override
            public void paintBorder(Component c, Graphics g, int x, int y, int width, int height) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

                // perbaikan utama: offset border agar tidak terpotong
                double inset = 0.5;
                double w = width - 1.0;
                double h = height - 1.0;

                g2.setColor(active ? focusColor : color);
                g2.draw(new RoundRectangle2D.Double(inset, inset, w - 1, h - 1, round, round));

                g2.dispose();
            }
        }
    }
}
