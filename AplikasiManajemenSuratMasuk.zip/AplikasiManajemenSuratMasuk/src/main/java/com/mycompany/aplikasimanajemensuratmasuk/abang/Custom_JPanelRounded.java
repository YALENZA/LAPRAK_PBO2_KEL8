package com.mycompany.aplikasimanajemensuratmasuk.abang;

import java.awt.*;
import java.awt.geom.*;
import javax.swing.*;

public class Custom_JPanelRounded extends JPanel {

    private int roundTopLeft = 0;
    private int roundTopRight = 0;
    private int roundBottomLeft = 0;
    private int roundBottomRight = 0;

    public Custom_JPanelRounded() {
        setOpaque(false);
    }

    // ===== Getter & Setter =====
    public int getRoundTopLeft() { return roundTopLeft; }
    public void setRoundTopLeft(int v) { roundTopLeft = v; repaint(); }

    public int getRoundTopRight() { return roundTopRight; }
    public void setRoundTopRight(int v) { roundTopRight = v; repaint(); }

    public int getRoundBottomLeft() { return roundBottomLeft; }
    public void setRoundBottomLeft(int v) { roundBottomLeft = v; repaint(); }

    public int getRoundBottomRight() { return roundBottomRight; }
    public void setRoundBottomRight(int v) { roundBottomRight = v; repaint(); }

    @Override
    protected void paintComponent(Graphics g) {
        Graphics2D g2 = (Graphics2D) g.create();
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        int width = getWidth();
        int height = getHeight();

        // Sama persis dengan versi gradient
        Shape shape = createRoundShape(width, height);

        g2.setColor(getBackground());
        g2.fill(shape);

        g2.dispose();
        super.paintComponent(g);
    }

    private Shape createRoundShape(int width, int height) {
        int tl = Math.min(roundTopLeft, Math.min(width, height));
        int tr = Math.min(roundTopRight, Math.min(width, height));
        int bl = Math.min(roundBottomLeft, Math.min(width, height));
        int br = Math.min(roundBottomRight, Math.min(width, height));

        Path2D path = new Path2D.Double();
        path.moveTo(tl, 0);
        path.lineTo(width - tr, 0);
        path.quadTo(width, 0, width, tr);
        path.lineTo(width, height - br);
        path.quadTo(width, height, width - br, height);
        path.lineTo(bl, height);
        path.quadTo(0, height, 0, height - bl);
        path.lineTo(0, tl);
        path.quadTo(0, 0, tl, 0);
        path.closePath();

        return path;
    }
}
