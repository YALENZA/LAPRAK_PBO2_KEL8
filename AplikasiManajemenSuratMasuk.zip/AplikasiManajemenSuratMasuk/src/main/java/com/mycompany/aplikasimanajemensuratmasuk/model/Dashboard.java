/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.aplikasimanajemensuratmasuk.model;

/**
 *
 * @author VICTUS
 */
public class Dashboard {
    private int jumlahSurat;
    private String namaSurat;

    public Dashboard(){
    }
    
    public Dashboard(int jumlahSurat, String namaSurat){
        this.jumlahSurat = jumlahSurat;
        this.namaSurat = namaSurat;
    }
    
    public void setNamaSurat(String namaSurat) {
        this.namaSurat = namaSurat;
    }

    public void setJumlahSurat(int jumlahSurat) {
        this.jumlahSurat = jumlahSurat;
    }

    public String getNamaSurat() {
        return namaSurat;   
    }

    public int getJumlahSurat() {
        return jumlahSurat;
    }
}
