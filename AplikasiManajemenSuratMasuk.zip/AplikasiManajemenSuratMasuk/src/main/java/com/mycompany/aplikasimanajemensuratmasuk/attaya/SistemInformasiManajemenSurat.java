/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.aplikasimanajemensuratmasuk.attaya;

/**
 *
 * @author User
 */
public class SistemInformasiManajemenSurat {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
