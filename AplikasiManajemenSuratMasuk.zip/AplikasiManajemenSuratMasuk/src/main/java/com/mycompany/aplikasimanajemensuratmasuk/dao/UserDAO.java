package com.mycompany.aplikasimanajemensuratmasuk.dao;

import com.mycompany.aplikasimanajemensuratmasuk.model.User;
import com.mycompany.aplikasimanajemensuratmasuk.config.Koneksi;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class UserDAO {

    // INSERT DATA
    public static void insert(User user) throws SQLException {
        String sql = "INSERT INTO user(username, password, nama_lengkap, no_hp, nim, role) VALUES(?,?,?,?,?,?)";

        try (Connection c = Koneksi.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {

            ps.setString(1, user.getUsername());
            ps.setString(2, user.getPassword());
            ps.setString(3, user.getNama_lengkap());
            ps.setString(4, user.getNo_hp());
            ps.setString(5, user.getNim());
            ps.setString(6, user.getRole());

            ps.executeUpdate();
        }
    }

    // UPDATE DATA BERDASARKAN id_user
    public static void updateById(User user) throws SQLException {
        String sql = "UPDATE user SET username = ?, password = ?, nama_lengkap = ?, no_hp = ?, nim = ?, role = ? WHERE id_user = ?";

        try (Connection c = Koneksi.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {

            ps.setString(1, user.getUsername());
            ps.setString(2, user.getPassword());
            ps.setString(3, user.getNama_lengkap());
            ps.setString(4, user.getNo_hp());
            ps.setString(5, user.getNim());
            ps.setString(6, user.getRole());
            ps.setInt(7, user.getId_user());

            ps.executeUpdate();
        }
    }

    // FIND BY ID
    public static User findById(int idUser) throws SQLException {
        String sql = "SELECT * FROM user WHERE id_user = ?";

        try (Connection c = Koneksi.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {

            ps.setInt(1, idUser);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    User user = new User();
                    user.setId_user(rs.getInt("id_user"));
                    user.setUsername(rs.getString("username"));
                    user.setPassword(rs.getString("password"));
                    user.setNama_lengkap(rs.getString("nama_lengkap"));
                    user.setNo_hp(rs.getString("no_hp"));
                    user.setNim(rs.getString("nim"));
                    user.setRole(rs.getString("role"));
                    return user;
                }
            }
        }
        return null;
    }

    // DELETE BY ID (HARD DELETE)
    public static void deleteById(int idUser) throws SQLException {
        String sql = "DELETE FROM user WHERE id_user = ?";

        try (Connection c = Koneksi.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {

            ps.setInt(1, idUser);
            ps.executeUpdate();
        }
    }

    // GET ALL USERS
    public static List<User> getAll() throws SQLException {
        List<User> list = new ArrayList<>();
        String sql = "SELECT * FROM user";

        try (Connection c = Koneksi.getConnection();
             Statement s = c.createStatement();
             ResultSet rs = s.executeQuery(sql)) {

            while (rs.next()) {
                User u = new User();
                u.setId_user(rs.getInt("id_user"));
                u.setUsername(rs.getString("username"));
                u.setPassword(rs.getString("password"));
                u.setNama_lengkap(rs.getString("nama_lengkap"));
                u.setNo_hp(rs.getString("no_hp"));
                u.setNim(rs.getString("nim"));
                u.setRole(rs.getString("role"));

                list.add(u);
            }
        }
        return list;
    }

    // LOGIN
    public static User login(String username, String password) throws SQLException {
        String sql = "SELECT * FROM user WHERE username = ? AND password = ?";

        try (Connection c = Koneksi.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {

            ps.setString(1, username);
            ps.setString(2, password);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    User u = new User();
                    u.setId_user(rs.getInt("id_user"));
                    u.setUsername(rs.getString("username"));
                    u.setPassword(rs.getString("password"));
                    u.setNama_lengkap(rs.getString("nama_lengkap"));
                    u.setNo_hp(rs.getString("no_hp"));
                    u.setNim(rs.getString("nim"));
                    u.setRole(rs.getString("role"));
                    return u;
                }
            }
        }
        return null;
    }
}
