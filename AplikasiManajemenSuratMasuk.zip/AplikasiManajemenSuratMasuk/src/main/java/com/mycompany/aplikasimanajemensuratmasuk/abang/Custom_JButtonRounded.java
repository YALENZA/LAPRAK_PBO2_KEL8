package com.mycompany.aplikasimanajemensuratmasuk.abang;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JButton;

public class Custom_JButtonRounded extends JButton {

    private boolean over;
    private Color fill;
    private Color fillOriginal;
    private Color fillOver;
    private Color fillClick;
    private int strokeWidth;
    private int roundedCorner;

    public Custom_JButtonRounded() {

        strokeWidth = 2;
        roundedCorner = 15;

        // Warna default
        fillOriginal = new Color(52, 152, 219);
        fillOver = adjustColor(fillOriginal, -25);
        fillClick = adjustColor(fillOriginal, -50);
        fill = fillOriginal;

        // Properti wajib untuk custom button
        setOpaque(false);
        setBorder(null);
        setFocusPainted(false);
        setContentAreaFilled(false);

        // Agar NetBeans Designer membaca warna
        super.setBackground(fillOriginal);
        setForeground(Color.WHITE);

        addMouseListener(new MouseAdapter() {

            @Override
            public void mouseExited(MouseEvent e) {
                over = false;
                fill = fillOriginal;
                repaint();
            }

            @Override
            public void mouseEntered(MouseEvent e) {
                over = true;
                fill = fillOver;
                repaint();
            }

            @Override
            public void mouseReleased(MouseEvent e) {
                fill = over ? fillOver : fillOriginal;
                repaint();
            }

            @Override
            public void mousePressed(MouseEvent e) {
                fill = fillClick;
                repaint();
            }
        });
    }

    // === Utility untuk adjust warna lebih gelap ===
    private Color adjustColor(Color c, int amount) {
        int r = Math.min(Math.max(c.getRed() + amount, 0), 255);
        int g = Math.min(Math.max(c.getGreen() + amount, 0), 255);
        int b = Math.min(Math.max(c.getBlue() + amount, 0), 255);
        return new Color(r, g, b);
    }


    // ===================================================
    // === BAGIAN PALING PENTING AGAR NETBEANS BERHASIL ===
    // ===================================================

    // NetBeans membaca background dari method ini → jangan diganti
    @Override
    public Color getBackground() {
        return super.getBackground();
    }

    // Set background dari Palette akan masuk ke sini
    @Override
    public void setBackground(Color bg) {
        super.setBackground(bg);   // agar NetBeans Designer berubah

        this.fillOriginal = bg;
        this.fillOver = adjustColor(bg, -25);
        this.fillClick = adjustColor(bg, -50);

        if (!over) {
            this.fill = fillOriginal;
        }

        repaint();
    }

    // ===================================================

    public int getRoundedCorner() {
        return roundedCorner;
    }

    public void setRoundedCorner(int roundedCorner) {
        this.roundedCorner = roundedCorner;
        repaint();
    }

    public int getStrokeWidth() {
        return strokeWidth;
    }

    public void setStrokeWidth(int strokeWidth) {
        this.strokeWidth = strokeWidth;
        repaint();
    }


    // === PAINT CUSTOM BUTTON ===
    @Override
    protected void paintComponent(Graphics g) {
        if (!isOpaque()) {
            Graphics2D g2d = (Graphics2D) g.create();
            g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
                    RenderingHints.VALUE_ANTIALIAS_ON);

            int s = strokeWidth;
            int w = getWidth() - (2 * s);
            int h = getHeight() - (2 * s);

            g2d.setColor(fill);
            g2d.fillRoundRect(s, s, w, h, roundedCorner, roundedCorner);

            g2d.dispose();
        }

        super.paintComponent(g);
    }
}
