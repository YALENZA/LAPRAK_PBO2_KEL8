/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.aplikasimanajemensuratmasuk.model;

import javax.swing.Icon;

/**
 *
 * @author VICTUS
 */
public class ModelCard {

    public String getNamaSurat() {
        return namaSurat;
    }

    public void setNamaSurat(String namaSurat) {
        this.namaSurat = namaSurat;
    }

    public int getJumlahSurat() {
        return jumlahSurat;
    }

    public void setJumlahSurat(int jumlahSurat) {
        this.jumlahSurat = jumlahSurat;
    }

    public ModelCard(String namaSurat, int jumlahSurat) {
        this.namaSurat = namaSurat;
        this.jumlahSurat = jumlahSurat;
    }
    
    public ModelCard(){
    }
    
    String namaSurat; 
    int jumlahSurat;
}
