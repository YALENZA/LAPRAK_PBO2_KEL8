package com.mycompany.aplikasimanajemensuratmasuk.dao;

import com.mycompany.aplikasimanajemensuratmasuk.config.Koneksi;
import com.mycompany.aplikasimanajemensuratmasuk.model.SuratKeluar;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class SuratKeluarDAO {

    // INSERT
    public static void insert(SuratKeluar s) throws SQLException {
        String sql = "INSERT INTO surat_keluar(no_surat, tanggal_keluar, pengirim, penerima, perihal, lampiran, foto) "
                   + "VALUES(?,?,?,?,?,?,?)";

        try (Connection c = Koneksi.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {

            ps.setString(1, s.getNo_surat());
            ps.setDate(2, Date.valueOf(s.getTanggal_keluar()));
            ps.setString(3, s.getPengirim());
            ps.setString(4, s.getPenerima());
            ps.setString(5, s.getPerihal());
            ps.setString(6, s.getLampiran());
            ps.setString(7, s.getFoto());

            ps.executeUpdate();
        }
    }
    
    // FUNGSI MENGHITUNG TOTAL SURAT KELUAR (Untuk Dashboard)
    public static int getCount() throws SQLException {
        int total = 0;
        String sql = "SELECT COUNT(*) AS total FROM surat_keluar";

        try (Connection c = Koneksi.getConnection();
             Statement s = c.createStatement();
             ResultSet rs = s.executeQuery(sql)) {

            if (rs.next()) {
                total = rs.getInt("total");
            }
        }
        return total;
    }

    // UPDATE BY ID
    public static void updateById(SuratKeluar s) throws SQLException {
        String sql = "UPDATE surat_keluar SET no_surat=?, tanggal_keluar=?, pengirim=?, penerima=?, "
                   + "perihal=?, lampiran=?, foto=? WHERE id_surat_keluar=?";

        try (Connection c = Koneksi.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {

            ps.setString(1, s.getNo_surat());
            ps.setDate(2, Date.valueOf(s.getTanggal_keluar()));
            ps.setString(3, s.getPengirim());
            ps.setString(4, s.getPenerima());
            ps.setString(5, s.getPerihal());
            ps.setString(6, s.getLampiran());
            ps.setString(7, s.getFoto());
            ps.setInt(8, s.getId_surat_keluar());

            ps.executeUpdate();
        }
    }

    // FIND BY ID
    public static SuratKeluar findById(int id) throws SQLException {
        String sql = "SELECT * FROM surat_keluar WHERE id_surat_keluar=?";

        try (Connection c = Koneksi.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {

            ps.setInt(1, id);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    SuratKeluar s = new SuratKeluar();
                    s.setId_surat_keluar(rs.getInt("id_surat_keluar"));
                    s.setNo_surat(rs.getString("no_surat"));
                    s.setTanggal_keluar(rs.getString("tanggal_keluar"));
                    s.setPengirim(rs.getString("pengirim"));
                    s.setPenerima(rs.getString("penerima"));
                    s.setPerihal(rs.getString("perihal"));
                    s.setLampiran(rs.getString("lampiran"));
                    s.setFoto(rs.getString("foto"));
                    return s;
                }
            }
        }

        return null;
    }

    // DELETE BY ID
    public static void deleteById(int id) throws SQLException {
        String sql = "DELETE FROM surat_keluar WHERE id_surat_keluar=?";

        try (Connection c = Koneksi.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {

            ps.setInt(1, id);
            ps.executeUpdate();
        }
    }

    // GET ALL
    public static List<SuratKeluar> getAll() throws SQLException {
        List<SuratKeluar> list = new ArrayList<>();
        String sql = "SELECT * FROM surat_keluar ORDER BY id_surat_keluar DESC";

        try (Connection c = Koneksi.getConnection();
             Statement s = c.createStatement();
             ResultSet rs = s.executeQuery(sql)) {

            while (rs.next()) {
                SuratKeluar sk = new SuratKeluar();
                sk.setId_surat_keluar(rs.getInt("id_surat_keluar"));
                sk.setNo_surat(rs.getString("no_surat"));
                sk.setTanggal_keluar(rs.getString("tanggal_keluar"));
                sk.setPengirim(rs.getString("pengirim"));
                sk.setPenerima(rs.getString("penerima"));
                sk.setPerihal(rs.getString("perihal"));
                sk.setLampiran(rs.getString("lampiran"));
                sk.setFoto(rs.getString("foto"));

                list.add(sk);
            }
        }

        return list;
    }

    // OPTIONAL: Find by No Surat
    public static SuratKeluar findByNoSurat(String noSurat) throws SQLException {
        String sql = "SELECT * FROM surat_keluar WHERE no_surat=?";

        try (Connection c = Koneksi.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {

            ps.setString(1, noSurat);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    SuratKeluar s = new SuratKeluar();
                    s.setId_surat_keluar(rs.getInt("id_surat_keluar"));
                    s.setNo_surat(rs.getString("no_surat"));
                    s.setTanggal_keluar(rs.getString("tanggal_keluar"));
                    s.setPengirim(rs.getString("pengirim"));
                    s.setPenerima(rs.getString("penerima"));
                    s.setPerihal(rs.getString("perihal"));
                    s.setLampiran(rs.getString("lampiran"));
                    s.setFoto(rs.getString("foto"));
                    return s;
                }
            }
        }

        return null;
    }
}