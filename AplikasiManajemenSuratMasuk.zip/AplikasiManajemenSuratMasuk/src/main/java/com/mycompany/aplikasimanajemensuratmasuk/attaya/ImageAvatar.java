/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.aplikasimanajemensuratmasuk.attaya;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.Shape;
import java.awt.geom.Ellipse2D;
import java.awt.image.BufferedImage;
import javax.swing.ImageIcon;
import javax.swing.JComponent;

public class ImageAvatar extends JComponent {

    private BufferedImage image;
    private int borderSize = 4;
    private Color borderColor = new Color(33, 150, 243);
    private Color backgroundColor = Color.LIGHT_GRAY;

    public ImageAvatar() {
        setPreferredSize(new Dimension(200, 200));
        setOpaque(false);
    }

    public void setImage(BufferedImage image) {
        this.image = image;
        repaint();
    }

    public BufferedImage getImage() {
        return image;
    }

    public int getBorderSize() {
        return borderSize;
    }

    public void setBorderSize(int borderSize) {
        this.borderSize = borderSize;
        repaint();
    }

    public Color getBorderColor() {
        return borderColor;
    }

    public void setBorderColor(Color borderColor) {
        this.borderColor = borderColor;
        repaint();
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);

        Graphics2D g2 = (Graphics2D) g.create();
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
                            RenderingHints.VALUE_ANTIALIAS_ON);

        int w = getWidth();
        int h = getHeight();
        int diameter = Math.min(w, h) - borderSize * 2;

        int x = (w - diameter) / 2;
        int y = (h - diameter) / 2;

        // Lingkaran background (warna abu2 kalau belum ada gambar)
        g2.setColor(backgroundColor);
        g2.fillOval(x, y, diameter, diameter);

        if (image != null) {
            // Clip jadi lingkaran supaya gambar ikut bulat
            Shape oldClip = g2.getClip();
            Ellipse2D circle = new Ellipse2D.Double(
                    x + borderSize,
                    y + borderSize,
                    diameter - borderSize * 2,
                    diameter - borderSize * 2
            );
            g2.setClip(circle);

            // Scale gambar supaya penuh
            double scale = Math.max(
                    (double) circle.getBounds().width / image.getWidth(),
                    (double) circle.getBounds().height / image.getHeight()
            );
            int imgW = (int) (image.getWidth() * scale);
            int imgH = (int) (image.getHeight() * scale);

            int imgX = (int) (circle.getBounds().getX()
                    + (circle.getBounds().width - imgW) / 2);
            int imgY = (int) (circle.getBounds().getY()
                    + (circle.getBounds().height - imgH) / 2);

            g2.drawImage(image, imgX, imgY, imgW, imgH, null);

            g2.setClip(oldClip);
        }

        // Border lingkaran
        g2.setColor(borderColor);
        g2.setStroke(new BasicStroke(borderSize));
        g2.drawOval(x, y, diameter, diameter);

        g2.dispose();
    }

        // Ganti method setIcon yang paling bawah dengan ini:
    public void setIcon(ImageIcon imageIcon) {
        if (imageIcon != null) {
            // Kita harus ubah ImageIcon jadi BufferedImage biar bisa diolah
            BufferedImage bimage = new BufferedImage(
                imageIcon.getIconWidth(), 
                imageIcon.getIconHeight(), 
                BufferedImage.TYPE_INT_ARGB
            );
            Graphics g = bimage.createGraphics();
            imageIcon.paintIcon(null, g, 0, 0);
            g.dispose();

            // Panggil method setImage yang sudah ada di atas
            setImage(bimage); 
        } else {
            setImage(null);
        }
    }
}

