package com.mycompany.aplikasimanajemensuratmasuk.abang;

import java.awt.*;
import java.awt.geom.*;
import javax.swing.*;

/**
 * Custom JPanel dengan gradient dan rounded corner yang dapat diatur per sudut.
 * 
 * Bisa digunakan langsung di NetBeans GUI Builder tanpa error.
 * 
 * Fitur:
 * - Warna gradient dapat dikustom (colorStart, colorEnd)
 * - Setiap sudut dapat diatur radius-nya sendiri
 * - Sudah antialiasing dan tidak terpotong
 */
public class Custom_JPanelRoundedGradient extends JPanel {

    // Gradient colors
    private Color colorStart = new Color(51, 51, 255);
    private Color colorEnd = new Color(51, 255, 204);

    // Radius tiap sudut
    private int roundTopLeft = 0;
    private int roundTopRight = 0;
    private int roundBottomLeft = 0;
    private int roundBottomRight = 0;

    public Custom_JPanelRoundedGradient() {
        setOpaque(false); // agar background transparan & kita bisa gambar sendiri
    }

    // ===== Getter & Setter untuk warna gradient =====
    public Color getColorStart() {
        return colorStart;
    }

    public void setColorStart(Color colorStart) {
        this.colorStart = colorStart;
        repaint();
    }

    public Color getColorEnd() {
        return colorEnd;
    }

    public void setColorEnd(Color colorEnd) {
        this.colorEnd = colorEnd;
        repaint();
    }

    // ===== Getter & Setter untuk tiap corner =====
    public int getRoundTopLeft() {
        return roundTopLeft;
    }

    public void setRoundTopLeft(int roundTopLeft) {
        this.roundTopLeft = roundTopLeft;
        repaint();
    }

    public int getRoundTopRight() {
        return roundTopRight;
    }

    public void setRoundTopRight(int roundTopRight) {
        this.roundTopRight = roundTopRight;
        repaint();
    }

    public int getRoundBottomLeft() {
        return roundBottomLeft;
    }

    public void setRoundBottomLeft(int roundBottomLeft) {
        this.roundBottomLeft = roundBottomLeft;
        repaint();
    }

    public int getRoundBottomRight() {
        return roundBottomRight;
    }

    public void setRoundBottomRight(int roundBottomRight) {
        this.roundBottomRight = roundBottomRight;
        repaint();
    }

    @Override
    protected void paintComponent(Graphics g) {
        // Setup grafik 2D dengan antialias
        Graphics2D g2 = (Graphics2D) g.create();
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        int width = getWidth();
        int height = getHeight();

        // Buat shape rounded per corner
        Shape shape = createRoundShape(width, height);

        // Buat gradient
        GradientPaint gp = new GradientPaint(0, 0, colorStart, width, height, colorEnd);

        g2.setPaint(gp);
        g2.fill(shape);

        g2.dispose();

        // Lanjutkan paint default (agar komponen anak tetap tampil)
        super.paintComponent(g);
    }

    /**
     * Membuat bentuk dengan radius berbeda tiap sudut
     */
    private Shape createRoundShape(int width, int height) {
        int tl = Math.min(roundTopLeft, Math.min(width, height));
        int tr = Math.min(roundTopRight, Math.min(width, height));
        int bl = Math.min(roundBottomLeft, Math.min(width, height));
        int br = Math.min(roundBottomRight, Math.min(width, height));

        // Buat path manual untuk 4 sudut
        Path2D path = new Path2D.Double();
        path.moveTo(tl, 0);
        path.lineTo(width - tr, 0);
        path.quadTo(width, 0, width, tr);
        path.lineTo(width, height - br);
        path.quadTo(width, height, width - br, height);
        path.lineTo(bl, height);
        path.quadTo(0, height, 0, height - bl);
        path.lineTo(0, tl);
        path.quadTo(0, 0, tl, 0);
        path.closePath();

        return path;
    }
}
