package com.mycompany.aplikasimanajemensuratmasuk.abang;

import java.awt.*;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.awt.geom.RoundRectangle2D;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.plaf.basic.BasicPasswordFieldUI;

/**
 * Custom JPasswordField dengan border rounded dan warna yang bisa dikustomisasi penuh.
 */
public class Custom_JPasswordFieldRounded extends JPasswordField {

    private final PasswordFieldUI passwordUI;

    public Custom_JPasswordFieldRounded() {
        passwordUI = new PasswordFieldUI(this);
        setUI(passwordUI);
    }

    // === Setter & Getter untuk warna dan bentuk ===
    public void setRound(int round) {
        passwordUI.setRound(round);
    }

    public int getRound() {
        return passwordUI.getRound();
    }

    public void setBorderColor(Color color) {
        passwordUI.getBorder().setColor(color);
        repaint();
    }

    public void setFocusColor(Color color) {
        passwordUI.getBorder().setFocusColor(color);
        repaint();
    }

    public void setBackgroundColor(Color color) {
        passwordUI.setBackgroundColor(color);
        repaint();
    }

    public void setPlaceholder(String text) {
        passwordUI.setPlaceholder(text);
        repaint();
    }

    public String getPlaceholder() {
        return passwordUI.getPlaceholder();
    }

    public void setPlaceholderColor(Color color) {
        passwordUI.setPlaceholderColor(color);
        repaint();
    }

    public Color getPlaceholderColor() {
        return passwordUI.getPlaceholderColor();
    }

    public Color getBackgroundColor() {
        return passwordUI.getBackgroundColor();
    }

    public Color getBorderColor() {
        return passwordUI.getBorder().getColor();
    }

    public Color getFocusColor() {
        return passwordUI.getBorder().getFocusColor();
    }

    // === Inner class utama ===
    private static class PasswordFieldUI extends BasicPasswordFieldUI {

        private final JPasswordField passwordField;
        private final Border border;
        private int round = 15;
        private Color backgroundColor = Color.WHITE;
        private Color placeholderColor = new Color(160, 160, 160);
        private String placeholder = "";

        public PasswordFieldUI(JPasswordField passwordField) {
            this.passwordField = passwordField;
            border = new Border(10);
            border.setRound(round);
            passwordField.setBorder(border);
            passwordField.setOpaque(false);
            passwordField.setSelectedTextColor(Color.WHITE);
            passwordField.setSelectionColor(new Color(54, 189, 248));

            // Efek fokus (ubah warna border)
            passwordField.addFocusListener(new FocusAdapter() {
                @Override
                public void focusGained(FocusEvent fe) {
                    border.setActive(true);
                    passwordField.repaint();
                }

                @Override
                public void focusLost(FocusEvent fe) {
                    border.setActive(false);
                    passwordField.repaint();
                }
            });
        }

        public void setRound(int round) {
            this.round = round;
            border.setRound(round);
            passwordField.repaint();
        }

        public int getRound() {
            return round;
        }

        public Border getBorder() {
            return border;
        }

        public void setBackgroundColor(Color color) {
            this.backgroundColor = color;
        }

        public Color getBackgroundColor() {
            return backgroundColor;
        }

        public void setPlaceholder(String text) {
            this.placeholder = text;
        }

        public String getPlaceholder() {
            return placeholder;
        }

        public void setPlaceholderColor(Color color) {
            this.placeholderColor = color;
        }

        public Color getPlaceholderColor() {
            return placeholderColor;
        }

        @Override
        protected void paintBackground(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

            int w = passwordField.getWidth();
            int h = passwordField.getHeight();

            Shape shape = new RoundRectangle2D.Double(
                    0.5, 0.5,
                    w - 1.0, h - 1.0,
                    round, round
            );

            g2.setColor(backgroundColor);
            g2.fill(shape);
            g2.dispose();
        }

        @Override
        protected void paintSafely(Graphics g) {
            super.paintSafely(g);

            // Placeholder (jika kosong dan tidak fokus)
            if (passwordField.getPassword().length == 0 && !passwordField.hasFocus() && !placeholder.isEmpty()) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(placeholderColor);
                FontMetrics fm = g2.getFontMetrics();
                int y = (passwordField.getHeight() - fm.getHeight()) / 2 + fm.getAscent();
                g2.drawString(placeholder, 10, y);
                g2.dispose();
            }
        }

        // === Inner class Border ===
        private static class Border extends EmptyBorder {

            private Color color = new Color(206, 212, 218);
            private Color focusColor = new Color(20, 93, 146);
            private int round;
            private boolean active = false;

            public Border(int padding) {
                super(padding, padding, padding, padding);
            }

            public void setColor(Color color) {
                this.color = color;
            }

            public Color getColor() {
                return color;
            }

            public void setFocusColor(Color color) {
                this.focusColor = color;
            }

            public Color getFocusColor() {
                return focusColor;
            }

            public void setRound(int round) {
                this.round = round;
            }

            public int getRound() {
                return round;
            }

            public void setActive(boolean active) {
                this.active = active;
            }

            @Override
            public void paintBorder(Component c, Graphics g, int x, int y, int width, int height) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

                double inset = 0.5;
                double w = width - 1.0;
                double h = height - 1.0;

                g2.setColor(active ? focusColor : color);
                g2.draw(new RoundRectangle2D.Double(inset, inset, w - 1, h - 1, round, round));

                g2.dispose();
            }
        }
    }
}
