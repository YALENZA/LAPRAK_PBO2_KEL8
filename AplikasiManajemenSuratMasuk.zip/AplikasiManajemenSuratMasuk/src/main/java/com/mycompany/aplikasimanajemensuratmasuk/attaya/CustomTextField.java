package com.mycompany.aplikasimanajemensuratmasuk.attaya;

import java.awt.*;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import javax.swing.JComponent;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.text.PlainDocument;

public class CustomTextField extends JComponent {

    private String hint = "Masukkan teks...";
    private int radius = 20;
    private boolean isFocused;
    private String text = "";

    
    public CustomTextField() {
        setOpaque(false);
        setFont(new Font("SansSerif", Font.PLAIN, 14));

        ((PlainDocument)getDocument()).addDocumentListener(new DocumentListener() {
            @Override public void insertUpdate(DocumentEvent e) { updateText(); }
            @Override public void removeUpdate(DocumentEvent e) { updateText(); }
            @Override public void changedUpdate(DocumentEvent e) { updateText(); }
        });

        addFocusListener(new FocusAdapter() {
            @Override public void focusGained(FocusEvent e) { isFocused = true; repaint(); }
            @Override public void focusLost(FocusEvent e) { isFocused = false; repaint(); }
        });

        setPreferredSize(new Dimension(200, 30));
    }

    private PlainDocument getDocument() {
        return new PlainDocument();
    }

    private void updateText() {
        repaint();
    }

    public String getText() {
        return text;
    }

    @Override
    protected void paintComponent(Graphics g) {
        Graphics2D g2 = (Graphics2D) g.create();
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        // background box
        g2.setColor(Color.WHITE);
        g2.fillRoundRect(1, 1, getWidth() - 2, getHeight() - 2, radius, radius);

        // border
        g2.setStroke(new BasicStroke(2f));
        g2.setColor(isFocused ? new Color(217,217,217) : new Color(217,217,217));
        g2.drawRoundRect(1, 1, getWidth() - 2, getHeight() - 2, radius, radius);

        // text or hint
        FontMetrics fm = g2.getFontMetrics();
        int textY = (getHeight() + fm.getAscent()) / 2 - 2;

        if (text.isEmpty() && !isFocused) {
            g2.setColor(new Color(130,130,130));
            g2.drawString(hint, 12, textY);
        } else {
            g2.setColor(Color.BLACK);
            g2.drawString(text, 12, textY);
        }

        g2.dispose();
    }
    
    
}
