/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.aplikasimanajemensuratmasuk.model;
import java.time.LocalDate;

/**
 *
 * @author User
 */
public class SuratMasuk {
    private int id;
    private String noSurat;
    private String tanggalMasuk;
    private String pengirim;
    private String penerima;
    private String perihal;
    private String lampiran;
    private String foto;
    private String status;

    public SuratMasuk() {
    }

    public SuratMasuk(String noSurat, String tanggalMasuk, String pengirim, String penerima, String perihal, String lampiran, String foto, String status) {
        this.noSurat = noSurat;
        this.tanggalMasuk = tanggalMasuk;
        this.pengirim = pengirim;
        this.penerima = penerima;
        this.perihal = perihal;
        this.lampiran = lampiran;
        this.foto = foto;
        this.status = status;
    }

    public SuratMasuk(int id, String noSurat, String tanggalMasuk, String pengirim, String penerima, String perihal, String lampiran, String foto, String status) {
        this.id = id;
        this.noSurat = noSurat;
        this.tanggalMasuk = tanggalMasuk;
        this.pengirim = pengirim;
        this.penerima = penerima;
        this.perihal = perihal;
        this.lampiran = lampiran;
        this.foto = foto;
        this.status = status;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNoSurat() {
        return noSurat;
    }

    public void setNoSurat(String noSurat) {
        this.noSurat = noSurat;
    }

    public String getTanggalMasuk() {
        return tanggalMasuk;
    }

    public void setTanggalMasuk(String tanggalMasuk) {
        this.tanggalMasuk = tanggalMasuk;
    }

    public String getPengirim() {
        return pengirim;
    }

    public void setPengirim(String pengirim) {
        this.pengirim = pengirim;
    }

    public String getPenerima() {
        return penerima;
    }

    public void setPenerima(String penerima) {
        this.penerima = penerima;
    }

    public String getPerihal() {
        return perihal;
    }

    public void setPerihal(String perihal) {
        this.perihal = perihal;
    }

    public String getLampiran() {
        return lampiran;
    }

    public void setLampiran(String lampiran) {
        this.lampiran = lampiran;
    }

    public String getFoto() {
        return foto;
    }

    public void setFoto(String foto) {
        this.foto = foto;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
    
    

}
