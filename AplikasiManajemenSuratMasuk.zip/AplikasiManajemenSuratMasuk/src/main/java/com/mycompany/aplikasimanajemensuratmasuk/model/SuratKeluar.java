/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.aplikasimanajemensuratmasuk.model;
import java.time.LocalDate;

/**
 *
 * @author User
 */
public class SuratKeluar {
    private int id_surat_keluar;
    private String no_surat;
    private String tanggal_keluar;
    private String pengirim;
    private String penerima;
    private String perihal;
    private String lampiran;
    private String foto;
    
    public SuratKeluar (){
        
    }
    
    public SuratKeluar (String no_surat,String tanggal_keluar, String pengirim, String penerima, String perihal, String lampiran, String foto ){
        this.no_surat = no_surat;
        this.tanggal_keluar = tanggal_keluar;
        this.pengirim = pengirim;
        this.penerima = penerima;
        this.perihal = perihal;
        this.lampiran = lampiran;
        this.foto = foto;
    }
    
    public SuratKeluar (int surat_keluar, String no_surat,String tanggal_keluar, String pengirim, String penerima, String perihal, String lampiran, String foto ){
        this.id_surat_keluar = id_surat_keluar;
        this.no_surat = no_surat;
        this.tanggal_keluar = tanggal_keluar;
        this.pengirim = pengirim;
        this.penerima = penerima;
        this.perihal = perihal;
        this.lampiran = lampiran;
        this.foto = foto;
    }

    public int getId_surat_keluar() {
        return id_surat_keluar;
    }

    public String getNo_surat() {
        return no_surat;
    }

    public String getTanggal_keluar() {
        return tanggal_keluar;
    }

    public String getPengirim() {
        return pengirim;
    }

    public String getPenerima() {
        return penerima;
    }

    public String getPerihal() {
        return perihal;
    }

    public String getLampiran() {
        return lampiran;
    }

    public String getFoto() {
        return foto;
    }

    public void setId_surat_keluar(int id_surat_keluar) {
        this.id_surat_keluar = id_surat_keluar;
    }

    public void setNo_surat(String no_surat) {
        this.no_surat = no_surat;
    }

    public void setTanggal_keluar(String tanggal_keluar) {
        this.tanggal_keluar = tanggal_keluar;
    }

    public void setPengirim(String pengirim) {
        this.pengirim = pengirim;
    }

    public void setPenerima(String penerima) {
        this.penerima = penerima;
    }

    public void setPerihal(String perihal) {
        this.perihal = perihal;
    }

    public void setLampiran(String lampiran) {
        this.lampiran = lampiran;
    }

    public void setFoto(String foto) {
        this.foto = foto;
    }  
}