/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.aplikasimanajemensuratmasuk.config;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Koneksi {
    private static Connection mysqlconfig;

    public static Connection getConnection() {
        try {
            // 1. Ini nama database sesuai screenshot kamu (JANGAN DIUBAH LAGI)
            String url = "jdbc:mysql://localhost:3306/aplikasimanajemensurat"; 
            String user = "root"; // Default XAMPP
            String pass = "";     // Default XAMPP (kosong)

            // 2. Register Driver
            DriverManager.registerDriver(new com.mysql.cj.jdbc.Driver());
            
            // 3. Buat Koneksi
            mysqlconfig = DriverManager.getConnection(url, user, pass);
            
        } catch (SQLException e) {
            System.err.println("Koneksi Gagal: " + e.getMessage()); 
            // Kalau gagal, kita return null biar ketahuan errornya di log
            return null; 
        }
        return mysqlconfig;
    }
}
