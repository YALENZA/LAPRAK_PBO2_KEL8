/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.aplikasimanajemensuratmasuk.config;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 *
 * @author User
 */
public class Koneksi {
    private static Connection conn;
    public static Connection getConnection() throws SQLException {
        if (conn == null || conn.isClosed()) {
            String jdbcUrl = "jdbc:mysql://127.0.0.1:3306/aplikasimanajemensuratmasuk";
            String username = "root";
            String password = "";
            conn = DriverManager.getConnection(jdbcUrl, username, password);
        }
        return conn;
    }
}
