package com.mycompany.aplikasimanajemensuratmasuk.attaya;

import java.awt.*;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.plaf.basic.BasicComboBoxUI;

public class ComboBoxCustom<T> extends JComboBox<T> {

    private int radius = 15;

    public ComboBoxCustom() {
        setOpaque(false); // biar bisa custom painting
        setBorder(new EmptyBorder(2, 5, 2, 5));
        setUI(new RoundedComboBoxUI());
    }

    public void setRadius(int radius) {
        this.radius = radius;
        repaint();
    }

    public int getRadius() {
        return radius;
    }

    private class RoundedComboBoxUI extends BasicComboBoxUI {

        @Override
        protected JButton createArrowButton() {
            JButton button = new JButton("\u25BC"); // panah bawah default
            button.setBorder(BorderFactory.createEmptyBorder());
            return button;
        }

        @Override
        public void paintCurrentValueBackground(Graphics g, Rectangle bounds, boolean hasFocus) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

            // background default
            g2.setColor(comboBox.getBackground());
            g2.fillRoundRect(0, 0, bounds.width, bounds.height, radius, radius);

            g2.dispose();
        }

        @Override
        public void paintCurrentValue(Graphics g, Rectangle bounds, boolean hasFocus) {
            super.paintCurrentValue(g, bounds, hasFocus);
        }

        @Override
        public void paint(Graphics g, JComponent c) {
            super.paint(g, c);

            // border round
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setColor(comboBox.getForeground().darker());
            g2.setStroke(new BasicStroke(1.2f));
            g2.drawRoundRect(0, 0, c.getWidth() - 1, c.getHeight() - 1, radius, radius);
            g2.dispose();
        }
    }
}
